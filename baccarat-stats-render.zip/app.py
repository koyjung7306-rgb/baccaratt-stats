from flask import Flask, render_template, request
import random

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        rounds = int(request.form.get("rounds", 10))
        outcomes = [random.choice(["Player", "Banker", "Tie"]) for _ in range(rounds)]
        p = outcomes.count("Player")
        b = outcomes.count("Banker")
        t = outcomes.count("Tie")
        result = {"Player": p, "Banker": b, "Tie": t, "Outcomes": outcomes}
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=10000)
